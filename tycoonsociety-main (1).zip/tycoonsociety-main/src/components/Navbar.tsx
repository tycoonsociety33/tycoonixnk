import { useState, useEffect } from 'react';
import { Menu, X, LogIn } from 'lucide-react';

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-dark-950/80 backdrop-blur-2xl border-b border-purple-500/10 shadow-lg shadow-purple-900/10'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-5 sm:px-8 lg:px-12">
        <div className="flex items-center justify-between py-4 sm:py-5">
          <a href="#" className="flex items-center gap-1.5 group">
            <span className="text-xl sm:text-2xl font-extrabold tracking-tight text-white">
              TYCOON
            </span>
            <span className="text-xl sm:text-2xl font-extrabold tracking-tight purple-gradient-text">
              SOCIETY
            </span>
          </a>

          <div className="hidden md:flex items-center gap-3">
            <button className="flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-purple-200/80 hover:text-white transition-colors duration-300 rounded-lg hover:bg-white/5">
              <LogIn size={16} />
              Login
            </button>
            <button className="cta-button px-7 py-2.5 rounded-lg text-sm tracking-wide uppercase">
              Intră în Sistem
            </button>
          </div>

          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden text-purple-300 hover:text-white transition-colors p-1"
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      <div
        className={`md:hidden overflow-hidden transition-all duration-400 ${
          mobileOpen ? 'max-h-48 opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <div className="px-5 pb-6 pt-2 bg-dark-950/95 backdrop-blur-2xl border-t border-purple-500/10 space-y-3">
          <button className="w-full flex items-center gap-2 px-4 py-3 text-sm font-medium text-purple-200/80 hover:text-white transition-colors text-left rounded-lg hover:bg-purple-500/10">
            <LogIn size={16} />
            Login
          </button>
          <button className="w-full cta-button px-6 py-3 rounded-lg text-sm tracking-wide uppercase">
            Intră în Sistem
          </button>
        </div>
      </div>
    </nav>
  );
}
