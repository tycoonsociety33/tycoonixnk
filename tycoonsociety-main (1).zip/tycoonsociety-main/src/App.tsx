import Navbar from './components/Navbar';
import Hero from './components/Hero';
import RealitateaPietei from './components/RealitateaPietei';
import HowItWorks from './components/HowItWorks';
import WhatMakesDifferent from './components/WhatMakesDifferent';
import ForWhom from './components/ForWhom';
import StandardCriterii from './components/StandardCriterii';
import Testimonials from './components/Testimonials';
import ArhitecturaEcosistemului from './components/ArhitecturaEcosistemului';
import Pricing from './components/Pricing';
import IntrebariEsentiale from './components/IntrebariEsentiale';
import FinalCTA from './components/FinalCTA';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-dark-950">
      <Navbar />
      <Hero />
      <RealitateaPietei />
      <HowItWorks />
      <WhatMakesDifferent />
      <ForWhom />
      <StandardCriterii />
      <Testimonials />
      <ArhitecturaEcosistemului />
      <Pricing />
      <IntrebariEsentiale />
      <FinalCTA />
      <Footer />
    </div>
  );
}

export default App;
